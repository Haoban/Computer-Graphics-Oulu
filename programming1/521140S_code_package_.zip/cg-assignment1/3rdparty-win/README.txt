These are the original Windows library packages for Visual Studio 2013 that are used in the distribution.

See contents for any license information etc.